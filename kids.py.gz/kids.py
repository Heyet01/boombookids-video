"""BoomBoo Kids: Gemini script -> TTS + music -> animated 16:9 video + 9:16 Short -> YouTube."""
import asyncio
import json
import math
import os
import random
import re
import subprocess
import sys
import time
import urllib.request
import wave
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

from chars import CHARS, COLORS, PROPS, char_sprite, col, prop

ROOT = Path(__file__).resolve().parent
FONT_BIG = str(ROOT / "assets" / "EricaOne-Regular.ttf")
FONT = str(ROOT / "assets" / "Outfit-Bold.ttf")
FPS, SR = 30, 44100
VOICE = os.environ.get("KIDS_VOICE", "en-US-AnaNeural")
TARGET = 15.0


def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)


# ------------------------------------------------------------------ script
TOPICS = ["colors", "numbers", "abc", "shapes", "rhyme"]
RHYMES = ["Twinkle Twinkle Little Star", "Row Row Row Your Boat", "Humpty Dumpty", "Baa Baa Black Sheep",
          "Itsy Bitsy Spider", "Hickory Dickory Dock", "Jack and Jill", "Hey Diddle Diddle", "Rain Rain Go Away",
          "Mary Had a Little Lamb", "Little Bo Peep", "Pat-a-Cake", "One Two Buckle My Shoe", "Star Light Star Bright",
          "Little Miss Muffet", "Hot Cross Buns", "Five Little Ducks", "Rock-a-bye Baby"]

SYS = """You write 15-second videos for BoomBoo Kids, an English YouTube channel for toddlers and preschoolers (ages 1-5) in the USA.
Hosts are our own characters: Boo (purple little monster with horns), Pip (yellow, round ears) and Momo (green, antenna). Never mention or imitate any other brand, show, or famous character.
Rules:
- Total spoken words 22-30. 4 or 5 lines. Each line max 8 very simple words. Cheerful, repetitive, easy to sing along.
- Line 1 is an excited hook that names the topic (e.g. "Hi friends! Let's count stars with Boo!").
- Last line invites them to sing again or say goodbye happily (e.g. "Yay! Let's do it again!").
- For a nursery rhyme only use the traditional public-domain words of that rhyme (first verse, shortened), plus a short hook and ending line.
- Every line has a "show" object describing a big simple picture: type is one of color, count, letter, shape, text.
  color: {"type":"color","color":"<name>","shape":"<prop>","label":"RED"}
  count: {"type":"count","count":1-5,"shape":"<prop>","color":"<name>","label":"THREE"}
  letter: {"type":"letter","letter":"A","word":"APPLE","shape":"<prop>","color":"<name>"}
  shape: {"type":"shape","shape":"<prop>","color":"<name>","label":"CIRCLE"}
  text: {"type":"text","shape":"<prop>","color":"<name>","label":"SHORT WORD"}
  <prop> must be one of: star, heart, square, triangle, circle, sun, moon, cloud, apple, balloon, flower, fish, car
  <name> must be one of: red, orange, yellow, green, blue, purple, pink, brown, black, white, gray
- Return ONLY JSON."""

USR = """Make video #{n}. Topic type: {topic}. {extra}
Recent titles (do not repeat the same idea): {recent}
Return JSON with keys:
"title": catchy YouTube title, max 60 chars, includes the main keyword parents search (e.g. "Learn Colors with Boo! Red Yellow Blue | Kids Song"), no emoji spam (max 1 emoji),
"thumb_text": 1-3 BIG words for the thumbnail (e.g. "COUNT 1-5!"),
"description": 2 short friendly sentences for parents + "Subscribe to BoomBoo Kids for new songs every day!" then a blank line and 6 hashtags (#kidssongs #nurseryrhymes #toddlerlearning #preschool #kidsvideos plus one topic tag),
"tags": array of 12 search tags,
"background": one of sky, meadow, night, beach, candy,
"friend": "pip" or "momo",
"song": "twinkle" if the rhyme is Twinkle Twinkle or Star Light, else "happy",
"lines": array of {{"say": "...", "show": {{...}}}}"""


def gemini(prompt, system):
    key = os.environ["KIDS_GEMINI_KEY"]
    body = json.dumps({"system_instruction": {"parts": [{"text": system}]},
                       "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                       "generationConfig": {"temperature": 0.9, "responseMimeType": "application/json"}}).encode()
    last = None
    for model in ["gemini-flash-latest", "gemini-2.5-flash", "gemini-flash-latest", "gemini-flash-lite-latest"]:
        try:
            req = urllib.request.Request(
                f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                data=body, headers={"Content-Type": "application/json", "x-goog-api-key": key})
            with urllib.request.urlopen(req, timeout=120) as r:
                out = json.loads(r.read())
            txt = out["candidates"][0]["content"]["parts"][0]["text"]
            txt = re.sub(r"^```(json)?|```$", "", txt.strip()).strip()
            return json.loads(txt)
        except Exception as e:  # noqa: BLE001
            last = e
            log("gemini", model, "failed:", str(e)[:200])
            time.sleep(15)
    raise RuntimeError(f"gemini failed: {last}")


def make_script(history):
    n = len(history) + 1
    topic = os.environ.get("KIDS_TOPIC") or TOPICS[(n - 1) % len(TOPICS)]
    extra = ""
    if topic == "rhyme":
        used = " ".join(h.get("title", "") for h in history[-30:]).lower()
        free = [r for r in RHYMES if r.split()[0].lower() not in used] or RHYMES
        extra = f"Use the nursery rhyme: {random.choice(free)}."
    recent = " | ".join(h.get("title", "") for h in history[-15:]) or "none"
    for attempt in range(3):
        job = gemini(USR.format(n=n, topic=topic, extra=extra, recent=recent), SYS)
        lines = job.get("lines") or []
        words = sum(len(str(l.get("say", "")).split()) for l in lines)
        if 3 <= len(lines) <= 6 and words <= 36:
            job["topic"] = topic
            return job
        log(f"script rejected ({len(lines)} lines, {words} words)")
    job["lines"] = job["lines"][:5]
    job["topic"] = topic
    return job


# ------------------------------------------------------------------ audio
async def _tts(text, mp3):
    import edge_tts
    words = []
    com = edge_tts.Communicate(text, VOICE, rate="-6%", pitch="+4Hz", boundary="WordBoundary")
    with open(mp3, "wb") as f:
        async for ch in com.stream():
            if ch["type"] == "audio":
                f.write(ch["data"])
            elif ch["type"] == "WordBoundary":
                words.append((ch["offset"] / 1e7, (ch["offset"] + ch["duration"]) / 1e7, ch["text"]))
    return words


def tts(text, work, i, offline=False):
    if offline:
        toks = text.split()
        t, ws = 0.1, []
        for tk in toks:
            d = 0.22 + 0.04 * len(tk)
            ws.append((t, t + d, tk))
            t += d + 0.05
        sr_t = np.arange(int(t * SR)) / SR
        return (0.25 * np.sin(2 * np.pi * 220 * sr_t) * (np.sin(2 * np.pi * 4 * sr_t) > 0)).astype(np.float32), ws
    mp3, wav = work / f"v{i}.mp3", work / f"v{i}.wav"
    for a in range(4):
        try:
            words = asyncio.run(_tts(text, str(mp3)))
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(mp3), "-ac", "1", "-ar", str(SR), str(wav)], check=True)
            with wave.open(str(wav)) as w:
                audio = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
            if not words:
                toks, dur = text.split(), len(audio) / SR
                words = [(j * dur / len(toks), (j + 1) * dur / len(toks), tk) for j, tk in enumerate(toks)]
            return audio, words
        except Exception as e:  # noqa: BLE001
            log("tts failed", e)
            time.sleep(4 * (a + 1))
    raise RuntimeError("tts failed")


def pluck(freq, dur, amp=0.18):
    t = np.arange(int(dur * SR)) / SR
    env = np.exp(-t * 6) * np.minimum(1, t * 200)
    w = np.sin(2 * np.pi * freq * t) + 0.35 * np.sin(4 * np.pi * freq * t) + 0.12 * np.sin(6 * np.pi * freq * t)
    return (w * env * amp).astype(np.float32)


def note(n):  # MIDI -> Hz
    return 440 * 2 ** ((n - 69) / 12)


def music(total, song, seed):
    n = int(total * SR) + SR
    out = np.zeros(n, np.float32)
    beat = 60 / 112
    chords = [[60, 64, 67], [55, 59, 62], [57, 60, 64], [53, 57, 60]]  # C G Am F
    t, k = 0.0, 0
    while t < total:
        ch = chords[(k // 8) % 4]
        nn = ch[k % 3] if k % 2 == 0 else ch[(k + 1) % 3] + 12
        i0 = int(t * SR)
        p = pluck(note(nn), beat * 0.9, 0.07)
        out[i0:i0 + len(p)] += p[: max(0, n - i0)]
        if k % 4 == 0:  # soft bass
            b = pluck(note(ch[0] - 12), beat * 1.8, 0.09)
            out[i0:i0 + len(b)] += b[: max(0, n - i0)]
        t += beat / 2
        k += 1
    if song == "twinkle":
        mel = [60, 60, 67, 67, 69, 69, 67, -1, 65, 65, 64, 64, 62, 62, 60, -1]
    else:
        mel = [67, 69, 67, 64, 65, 67, 72, -1, 71, 69, 67, 65, 64, 62, 60, -1]
    t, k = 0.0, 0
    while t < total:
        m = mel[k % len(mel)]
        if m > 0:
            i0 = int(t * SR)
            p = pluck(note(m + 12), beat, 0.045)
            out[i0:i0 + len(p)] += p[: max(0, n - i0)]
        t += beat
        k += 1
    fade = int(SR * 1.0)
    out[int(total * SR) - fade:int(total * SR)] *= np.linspace(1, 0, fade)
    out[int(total * SR):] = 0
    return out


def boing(dur=0.25, amp=0.18):
    t = np.arange(int(dur * SR)) / SR
    f = 300 + 500 * t / dur
    return (np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 12) * amp).astype(np.float32)


# ------------------------------------------------------------------ drawing helpers
BGS = {
    "sky": ((120, 200, 255), (200, 235, 255)), "meadow": ((150, 220, 255), (120, 210, 110)),
    "night": ((25, 30, 90), (80, 60, 150)), "beach": ((120, 210, 255), (255, 225, 150)),
    "candy": ((255, 190, 225), (190, 170, 255)),
}


def background(W, H, kind, seed):
    a, b = BGS.get(kind, BGS["sky"])
    y = np.linspace(0, 1, H)[:, None, None]
    img = (np.array(a)[None, None] * (1 - y) + np.array(b)[None, None] * y) * np.ones((1, W, 1))
    im = Image.fromarray(img.astype(np.uint8))
    d = ImageDraw.Draw(im)
    rng = random.Random(seed)
    if kind == "meadow":
        d.ellipse((-W * .2, H * .72, W * .7, H * 1.3), fill=(90, 190, 90))
        d.ellipse((W * .4, H * .76, W * 1.3, H * 1.3), fill=(110, 200, 100))
    elif kind == "beach":
        d.rectangle((0, H * .55, W, H * .7), fill=(70, 170, 235))
    elif kind == "night":
        for _ in range(60):
            x, yy, r = rng.random() * W, rng.random() * H * .7, rng.random() * 3 + 1
            d.ellipse((x - r, yy - r, x + r, yy + r), fill=(255, 250, 200))
    for _ in range(14):  # soft dots/bubbles
        x, yy, r = rng.random() * W, rng.random() * H, rng.randint(10, 40) * W / 1920
        d.ellipse((x - r, yy - r, x + r, yy + r), fill=(255, 255, 255))
    floor = H * (0.86 if W > H else 0.9)
    d.rectangle((0, floor, W, H), fill=tuple(int(v * .85) for v in b))
    return im.filter(ImageFilter.GaussianBlur(1)), floor


def text_img(text, size, fill=(255, 214, 40), stroke=(60, 20, 120), font=FONT_BIG, max_w=None):
    while True:
        f = ImageFont.truetype(font, size)
        sw = max(4, size // 9)
        l, t, r, b = f.getbbox(text, stroke_width=sw)
        if not max_w or r - l <= max_w or size < 30:
            break
        size -= 6
    im = Image.new("RGBA", (r - l + 20, b - t + 20), (0, 0, 0, 0))
    ImageDraw.Draw(im).text((10 - l, 10 - t), text, font=f, fill=fill, stroke_width=sw, stroke_fill=stroke)
    return im


def caption_img(words, active, max_w, size):
    f = ImageFont.truetype(FONT, size)
    sw = max(3, size // 8)
    space = f.getlength(" ")
    widths = [f.getlength(w) for w in words]
    while sum(widths) + space * (len(words) - 1) > max_w and size > 24:
        size -= 4
        f = ImageFont.truetype(FONT, size)
        sw = max(3, size // 8)
        space = f.getlength(" ")
        widths = [f.getlength(w) for w in words]
    total = sum(widths) + space * (len(words) - 1)
    asc, desc = f.getmetrics()
    im = Image.new("RGBA", (int(total + 2 * sw + 20), asc + desc + 2 * sw + 20), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    x = sw + 10
    for i, w in enumerate(words):
        d.text((x, sw + 10), w, font=f, fill=(255, 214, 40) if i == active else (255, 255, 255),
               stroke_width=sw, stroke_fill=(60, 20, 120))
        x += widths[i] + space
    return im


def paste(base, sp, cx, cy, scale=1.0, rot=0.0, alpha=1.0):
    if scale != 1.0:
        sp = sp.resize((max(1, int(sp.width * scale)), max(1, int(sp.height * scale))), Image.BILINEAR)
    if rot:
        sp = sp.rotate(rot, resample=Image.BILINEAR, expand=True)
    if alpha < 1:
        a = sp.getchannel("A").point(lambda v: int(v * alpha))
        sp = sp.copy()
        sp.putalpha(a)
    base.alpha_composite(sp, (int(cx - sp.width / 2), int(cy - sp.height / 2)))


def show_layer(show, size, t_in):
    """Return list of (sprite, dx, dy, scale) for the line's picture, relative to center."""
    typ = str(show.get("type", "shape"))
    shape = show.get("shape") if show.get("shape") in PROPS else "star"
    color = col(show.get("color", "red"))
    items = []
    pop = min(1.0, t_in / 0.35)
    pop = 1 + 0.25 * math.sin(pop * math.pi) if pop < 1 else 1.0
    if typ == "count":
        n = max(1, min(5, int(show.get("count", 3) or 3)))
        s = int(size * (0.75 if n == 1 else 0.55 if n == 2 else 0.42))
        sp = prop(shape, s, color)
        gap = s * 0.98
        rows = [list(range(min(n, 3))), list(range(3, n))] if n > 3 else [list(range(n))]
        for ri, row in enumerate(rows):
            if not row:
                continue
            dy = (ri - (len(rows) - 1) / 2) * gap
            for j, i in enumerate(row):
                appear = min(1.0, max(0.0, (t_in - i * 0.35) / 0.3))
                if appear <= 0:
                    continue
                items.append((sp, (j - (len(row) - 1) / 2) * gap, dy, appear * (1 + 0.15 * math.sin(appear * math.pi))))
    elif typ == "letter":
        letter = str(show.get("letter", "A"))[:1].upper()
        items.append((text_img(letter, int(size * 0.9), fill=color), -size * 0.45, 0, pop))
        items.append((prop(shape, int(size * 0.7), color), size * 0.45, 0, pop))
    else:
        items.append((prop(shape, size, color), 0, 0, pop))
    return items


# ------------------------------------------------------------------ render
def render(job, out_dir, offline=False):
    work = out_dir / "work"
    work.mkdir(parents=True, exist_ok=True)
    seed = random.randint(1, 10 ** 6)
    lines = job["lines"]
    friend = job.get("friend") if job.get("friend") in ("pip", "momo") else random.choice(["pip", "momo"])
    voices, words = [], []
    for i, ln in enumerate(lines):
        a, w = tts(str(ln["say"]), work, i, offline)
        voices.append(a)
        words.append(w)
    gap, lead = 0.3, 0.5
    starts, t = [], lead
    for a in voices:
        starts.append(t)
        t += len(a) / SR + gap
    total = max(TARGET, t + 0.8)
    log(f"total {total:.1f}s")
    n = int(total * SR) + SR
    voice = np.zeros(n, np.float32)
    for a, st in zip(voices, starts):
        voice[int(st * SR):int(st * SR) + len(a)] += a
    if np.abs(voice).max() > 0:
        voice *= 0.9 / np.abs(voice).max()
    sfx = np.zeros(n, np.float32)
    for st in starts:
        b = boing()
        sfx[int(st * SR):int(st * SR) + len(b)] += b
    mix = voice + music(total, job.get("song", "happy"), seed) + sfx
    mix = np.tanh(mix * 1.05) / np.tanh(1.05)
    wav = work / "mix.wav"
    with wave.open(str(wav), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((np.clip(mix[:int(total * SR)], -1, 1) * 32767).astype(np.int16).tobytes())

    # mouth openness from voice envelope
    env = np.abs(voice)
    hop = SR // FPS
    mouth_env = np.array([env[i * hop:(i + 1) * hop].mean() if i * hop < n else 0 for i in range(int(total * FPS) + 2)])
    if mouth_env.max() > 0:
        mouth_env = np.clip(mouth_env / (mouth_env.max() * 0.6), 0, 1)

    # captions: words grouped per line
    caps = []
    for wl, st in zip(words, starts):
        caps.append((st + wl[0][0] - 0.05, st + wl[-1][1] + 0.25, [(st + a, w) for a, b, w in wl]))

    sprites = {}

    def spr(name, size, blink, mouth, wave_):
        key = (name, size, round(blink, 1), round(mouth * 3) / 3, round(wave_, 1))
        if key not in sprites:
            sprites[key] = char_sprite(name, size, key[2], key[3], key[4])
        return sprites[key]

    outs = {}
    for fmt, (W, H) in {"long": (1920, 1080), "short": (1080, 1920)}.items():
        bg, floor = background(W, H, job.get("background", "sky"), seed)
        bg = bg.convert("RGBA")
        boo_sz = int(H * 0.62) if W > H else int(W * 0.66)
        fr_sz = int(boo_sz * 0.8)
        if W > H:
            boo_x, fr_x, pic_c, pic_s, cap_y, lab_y = W * 0.16, W * 0.85, (W * 0.5, H * 0.45), int(H * 0.5), H * 0.9, H * 0.11
        else:
            boo_x, fr_x, pic_c, pic_s, cap_y, lab_y = W * 0.3, W * 0.74, (W * 0.5, H * 0.33), int(W * 0.7), H * 0.56, H * 0.12
        path = out_dir / f"{fmt}.mp4"
        ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
                               "-r", str(FPS), "-i", "-", "-i", str(wav), "-map", "0:v", "-map", "1:a",
                               "-c:v", "libx264", "-preset", "veryfast" if offline else "medium", "-crf", "20",
                               "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-ar", "44100", "-ac", "2",
                               "-shortest", "-movflags", "+faststart", str(path)], stdin=subprocess.PIPE)
        nfr = int(total * FPS)
        cap_cache, lab_cache = {}, {}
        for f in range(nfr):
            t = f / FPS
            fr = bg.copy()
            li = max([i for i, s in enumerate(starts) if s - 0.15 <= t] or [0])
            # picture
            show = lines[li].get("show", {})
            for sp, dx, dy, sc in show_layer(show, pic_s, t - starts[li] + 0.15):
                bob = math.sin(t * 2.4 + dx) * pic_s * 0.025
                paste(fr, sp, pic_c[0] + dx, pic_c[1] + dy + bob, sc, rot=math.sin(t * 1.7 + dx) * 4)
            # label
            label = str(show.get("label") or show.get("word") or "").upper()[:16]
            if label:
                if label not in lab_cache:
                    lab_cache[label] = text_img(label, int(H * (0.11 if W > H else 0.065)), max_w=W * 0.9)
                p_in = min(1.0, (t - starts[li] + 0.15) / 0.3)
                paste(fr, lab_cache[label], W / 2, lab_y, 0.6 + 0.4 * p_in + 0.04 * math.sin(t * 6))
            # characters
            m = mouth_env[min(f, len(mouth_env) - 1)]
            blink = 1.0 if (f % 95) in (0, 1, 2) else 0.0
            hop_y = abs(math.sin(t * math.pi * 112 / 60)) * boo_sz * 0.07
            squash = 1 + 0.04 * math.sin(t * math.pi * 224 / 60)
            boo_sp = spr("boo", boo_sz, blink, m, 0.5 + 0.5 * math.sin(t * 5))
            paste(fr, boo_sp, boo_x, floor - boo_sz * 0.42 - hop_y, squash, rot=math.sin(t * 3) * 5)
            fb = 1.0 if ((f + 40) % 110) in (0, 1, 2) else 0.0
            fhop = abs(math.sin(t * math.pi * 112 / 60 + 1.2)) * fr_sz * 0.08
            fr_sp = spr(friend, fr_sz, fb, 0.15 + 0.1 * math.sin(t * 8), 0.5 + 0.5 * math.sin(t * 4 + 1))
            paste(fr, fr_sp, fr_x, floor - fr_sz * 0.42 - fhop, rot=-math.sin(t * 3 + 1) * 5)
            # caption
            for ci, (a, b, wl) in enumerate(caps):
                if a <= t <= b:
                    act = max([k for k, (wa, _) in enumerate(wl) if wa <= t + 0.03] or [0])
                    key = (ci, act)
                    if key not in cap_cache:
                        cap_cache[key] = caption_img([w for _, w in wl], act, W * 0.9, int(H * (0.075 if W > H else 0.05)))
                    paste(fr, cap_cache[key], W / 2, cap_y)
                    break
            # intro pop & outro subscribe
            if t > total - 1.6:
                sub = text_img("SUBSCRIBE!", int(H * (0.09 if W > H else 0.05)), fill=(255, 60, 60), stroke=(255, 255, 255))
                paste(fr, sub, W / 2, H * 0.5, 1 + 0.06 * math.sin(t * 10))
            ff.stdin.write(np.asarray(fr.convert("RGB")).tobytes())
        ff.stdin.close()
        ff.wait()
        outs[fmt] = path
        log("rendered", fmt, path.stat().st_size // 1024, "KB")

    # thumbnail 1280x720
    th, floor = background(1280, 720, job.get("background", "sky"), seed)
    th = th.convert("RGBA")
    rays = Image.new("RGBA", th.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(rays)
    for i in range(14):
        a = i * math.pi / 7
        d.polygon([(330, 400), (330 + 1500 * math.cos(a), 400 + 1500 * math.sin(a)),
                   (330 + 1500 * math.cos(a + 0.2), 400 + 1500 * math.sin(a + 0.2))], fill=(255, 255, 255, 55))
    th.alpha_composite(rays)
    show = next((l.get("show") for l in lines if l.get("show", {}).get("type") != "text"), lines[0].get("show", {}))
    for sp, dx, dy, sc in show_layer(show, 360, 5):
        paste(th, sp, 930 + dx * 0.8, 300 + dy, 1.0, rot=-6)
    paste(th, char_sprite("boo", 600, 0, 0.9, 1.0), 290, 420)
    tt = str(job.get("thumb_text") or "SING WITH BOO!").upper()[:20]
    paste(th, text_img(tt, 120, max_w=1180), 640, 620, rot=-3)
    thumb = out_dir / "thumb.jpg"
    th.convert("RGB").save(thumb, quality=92)
    return {"long": outs["long"], "short": outs["short"], "thumb": thumb, "duration": round(total, 2), "friend": friend}


# ------------------------------------------------------------------ YouTube
def access_token():
    body = json.dumps({"client_id": os.environ["KIDS_CLIENT_ID"], "client_secret": os.environ["KIDS_CLIENT_SECRET"],
                       "refresh_token": os.environ["KIDS_REFRESH_TOKEN"], "grant_type": "refresh_token"}).encode()
    req = urllib.request.Request("https://oauth2.googleapis.com/token", data=body, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read())["access_token"]


def upload(tok, path, title, desc, tags):
    meta = {"snippet": {"title": title[:100], "description": desc[:4900], "tags": tags[:30], "categoryId": "27",
                        "defaultLanguage": "en", "defaultAudioLanguage": "en"},
            "status": {"privacyStatus": os.environ.get("KIDS_PRIVACY", "public"), "selfDeclaredMadeForKids": True,
                       "containsSyntheticMedia": False, "embeddable": True}}
    data = Path(path).read_bytes()
    req = urllib.request.Request(
        "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
        data=json.dumps(meta).encode(), method="POST",
        headers={"Authorization": f"Bearer {tok}", "Content-Type": "application/json; charset=UTF-8",
                 "X-Upload-Content-Type": "video/mp4", "X-Upload-Content-Length": str(len(data))})
    with urllib.request.urlopen(req, timeout=60) as r:
        loc = r.headers["Location"]
    req = urllib.request.Request(loc, data=data, method="PUT", headers={"Content-Type": "video/mp4"})
    with urllib.request.urlopen(req, timeout=600) as r:
        return json.loads(r.read())["id"]


def set_thumb(tok, vid, path):
    req = urllib.request.Request(f"https://www.googleapis.com/upload/youtube/v3/thumbnails/set?videoId={vid}",
                                 data=Path(path).read_bytes(), method="POST",
                                 headers={"Authorization": f"Bearer {tok}", "Content-Type": "image/jpeg"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return r.status


# ------------------------------------------------------------------ main
def main():
    offline = "--offline" in sys.argv
    dry = offline or os.environ.get("KIDS_DRY_RUN") == "1"
    out = ROOT / "out"
    out.mkdir(exist_ok=True)
    hist_p = ROOT / "history.json"
    history = json.loads(hist_p.read_text()) if hist_p.exists() else []
    if os.environ.get("KIDS_JOB"):
        job = json.loads(Path(os.environ["KIDS_JOB"]).read_text())
    else:
        job = make_script(history)
    log("job", json.dumps(job, ensure_ascii=False)[:1500])
    info = render(job, out, offline)
    title = str(job.get("title", "Sing with Boo!")).replace("<", "").replace(">", "")
    desc = str(job.get("description", "")).replace("<", "").replace(">", "")
    tags = [str(t)[:30] for t in job.get("tags", [])] + ["BoomBoo Kids", "kids songs", "nursery rhymes"]
    rec = {"time": time.strftime("%Y-%m-%d %H:%M"), "title": title, "topic": job.get("topic"),
           "script": " / ".join(l["say"] for l in job["lines"]), "duration": info["duration"]}
    if not dry:
        tok = access_token()
        vid = upload(tok, info["long"], title, desc, tags)
        log("long uploaded", vid)
        try:
            set_thumb(tok, vid, info["thumb"])
        except Exception as e:  # noqa: BLE001
            log("thumbnail failed", e)
        sid = upload(tok, info["short"], (title[:88] + " #shorts"), desc + "\n#shorts", tags)
        log("short uploaded", sid)
        rec.update(video=vid, short=sid)
    history.append(rec)
    hist_p.write_text(json.dumps(history[-200:], ensure_ascii=False, indent=1))
    (out / "summary.json").write_text(json.dumps(rec, ensure_ascii=False, indent=1))
    log("done", json.dumps(rec, ensure_ascii=False))


if __name__ == "__main__":
    main()
